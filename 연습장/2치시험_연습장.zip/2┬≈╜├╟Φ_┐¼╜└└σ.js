const h1 = document.getElementById("hint1");
const h2 = document.getElementById("hint2");
const h3 = document.getElementById("hint3");
const h4 = document.getElementById("hint4");
const h5 = document.getElementById("hint5");

function 힌트보기1() {
  h1.style.display = "block";
}
function 힌트숨기기1() {
  h1.style.display = "none";
}
function 힌트보기2() {
  h2.style.display = "block";
}
function 힌트숨기기2() {
  h2.style.display = "none";
}
function 힌트보기3() {
  h3.style.display = "block";
}
function 힌트숨기기3() {
  h3.style.display = "none";
}
function 힌트보기4() {
  h4.style.display = "block";
}
function 힌트숨기기4() {
  h4.style.display = "none";
}
function 힌트보기5() {
  h5.style.display = "block";
}

function 힌트숨기기5() {
  h5.style.display = "none";
}
